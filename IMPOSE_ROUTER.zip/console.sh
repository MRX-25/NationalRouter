./dgate "--dolua:package.cpath=package.cpath..';/usr/lib/lib?51.so';package.path=package.path..';./lua/?.lua';dofile('lua/console.wlua')"
