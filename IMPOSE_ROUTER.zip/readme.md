This is the new **conquest DICOM server** source code repository, it is the first ever release of the full source code of Conquest Dicom server with full source code, including the windows GUI.

[Web page] https://ingenium.home.xs4all.nl/dicom.html

[Forum] (https://forum.image-systems.biz/forum/index.php?board/33-conquest-users/)

[Download current stable release 1.5.0] (http://ingenium.home.xs4all.nl/dicomserver/dicomserver150.zip)

The commit corresponding to 1.5.0 is here: https://github.com/marcelvanherk/Conquest-DICOM-Server/commit/d963df1b66270f89e86b28be121f7c0913479ec4
