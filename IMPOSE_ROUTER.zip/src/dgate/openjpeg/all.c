#define OPJ_STATIC
#include "bio.c"
#include "cio.c"
#include "dwt.c"
#include "event.c"
#include "image.c"
#include "invert.c"
#include "j2k.c"
#include "jp2.c"
#include "mct.c"
#include "mqc.c"
#include "openjpeg.c"
#include "opj_clock.c"
#include "pi.c"
#include "raw.c"
#include "t1.c"
#include "t2.c"
#include "tcd.c"
#include "tgt.c"
#include "function_list.c"





