#define CHARLS_STATIC
#include "interface.cpp"
#include "jpegls.cpp"
#include "jpegmarkersegment.cpp"
#include "header.cpp"
#include "jpegstreamwriter.cpp"

